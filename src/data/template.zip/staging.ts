export const BaseUrl = "https://reqres.in/api/users";

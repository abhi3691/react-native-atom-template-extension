import {Dimensions} from 'react-native';

const ScreenRatio = Dimensions.get('window');

export default ScreenRatio;

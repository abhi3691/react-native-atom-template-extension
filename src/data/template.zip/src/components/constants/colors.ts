const colors = {
  white: '#fff',
  black: '#000',
  blue: '#061045',
  bgColor: '#f2f2f2',
};

export default colors;

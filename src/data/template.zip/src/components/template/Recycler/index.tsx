import {View} from 'react-native';
import React from 'react';

const Recycler = () => {
  return <View></View>;
};

export default Recycler;

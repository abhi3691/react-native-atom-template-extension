import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  footer: {
    height: 100,
  },
});
export default styles;

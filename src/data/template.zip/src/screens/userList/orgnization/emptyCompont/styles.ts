import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  emptyText: {
    color: '#d2d2d2',
    fontSize: 12,
  },
});
export default styles;

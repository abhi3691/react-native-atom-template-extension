module.exports = {
    project: {
        ios: {
            automaticPodsInstallation: true
        },
        android: {}
    },
    assets: ["./src/assets/fonts"]
};